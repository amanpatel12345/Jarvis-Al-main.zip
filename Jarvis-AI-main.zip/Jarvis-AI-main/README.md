## JARVIS AI

### Steps to run on your system.
Run following commands on terminal
- git clone https://github.com/Dhruv58/Jarvis-AI.git
- conda create --name myenv
- Activate Virtual Environment
  - Windows
    - conda activate myenv
  - Linux
    - source activate myenv
- pip install -r requirements.txt
- python main.py
